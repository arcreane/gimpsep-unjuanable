#include <QMainWindow>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void openPicture();
    void openImages();
    void panorama();
    void cannyEdgeDetection();
    void updateDilation(int dilationSize);
    void updateErosion(int erosionSize);
    void updateImageSize(int size);
    void updateBrightness(int level);
    void savePicture();

private:
    Ui::MainWindow *ui;
    QGraphicsScene *scene;
    QGraphicsPixmapItem *pixmapItem;
    QImage image;
    QList<QImage> images;
    QList<QGraphicsPixmapItem*> pixmapItems;
    QSize viewSize;
};

