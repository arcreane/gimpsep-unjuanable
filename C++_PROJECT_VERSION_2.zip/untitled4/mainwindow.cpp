#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QAction>
#include <QToolBar>
#include <QFileDialog>
#include <QLabel>
#include <vector>
#include <QSpinBox>
#include <QVBoxLayout>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QMenu *fileMenu = menuBar()->addMenu(tr("&File"));
    QAction *openAct = new QAction(tr("&Open Picture"), this);
    fileMenu->addAction(openAct);
    connect(openAct, &QAction::triggered, this, &MainWindow::openPicture);
    QAction *openImgsAct = new QAction(tr("&Open Images"), this);
    fileMenu->addAction(openImgsAct);
    connect(openImgsAct, &QAction::triggered, this, &MainWindow::openImages);

    QAction *saveAct = new QAction(tr("&Save Picture"), this);
    fileMenu->addAction(saveAct);
    connect(saveAct, &QAction::triggered, this, &MainWindow::savePicture);

    QMenu *toolsMenu = menuBar()->addMenu(tr("&Tools"));
    QAction *panoramaAct = new QAction(tr("&Panorama"), this);
    toolsMenu->addAction(panoramaAct);
    connect(panoramaAct, &QAction::triggered, this, &MainWindow::panorama);


    QAction *cannyAct = new QAction(tr("&Canny Edge Detection"), this);
    toolsMenu->addAction(cannyAct);
    connect(cannyAct, &QAction::triggered, this, &MainWindow::cannyEdgeDetection);

    QLabel *resizeLabel = new QLabel(tr("Resizing"), this);
    QSpinBox *sizeSpinBox = new QSpinBox(this);
    sizeSpinBox->setRange(0, 1000); // 设置范围
    connect(sizeSpinBox, QOverload<int>::of(&QSpinBox::valueChanged), this, &MainWindow::updateImageSize);

    QLabel *lightenDarkenLabel = new QLabel(tr("Lighten/Darken"), this);
    QSpinBox *brightnessSpinBox = new QSpinBox(this);
    brightnessSpinBox->setRange(-100, 100);
    connect(brightnessSpinBox, QOverload<int>::of(&QSpinBox::valueChanged), this, &MainWindow::updateBrightness);

    QLabel *dilateLabel = new QLabel(tr("Dilate"), this);
    QSpinBox *dilateSpinBox = new QSpinBox(this);
    dilateSpinBox->setRange(0, 100);
    connect(dilateSpinBox, QOverload<int>::of(&QSpinBox::valueChanged), this, &MainWindow::updateDilation);

    QLabel *erodeLabel = new QLabel(tr("Erode"), this);
    QSpinBox *erodeSpinBox = new QSpinBox(this);
    erodeSpinBox->setRange(0, 100);
    connect(erodeSpinBox, QOverload<int>::of(&QSpinBox::valueChanged), this, &MainWindow::updateErosion);

    QLabel *imageLabel = new QLabel(tr("Image Display"), this);
    scene = new QGraphicsScene(this);
    pixmapItem = new QGraphicsPixmapItem();
    scene->addItem(pixmapItem);
    QGraphicsView *view = new QGraphicsView(scene, this);

    QLabel *cannyKernelSizeLabel = new QLabel(tr("Canny Kernel Size"), this);
    QSpinBox *cannyKernelSizeSpinBox = new QSpinBox(this);
    cannyKernelSizeSpinBox->setRange(3, 7); // 设置范围，只允许3，5，7（Canny函数要求kernel size为3，5或7）
    cannyKernelSizeSpinBox->setSingleStep(2); // 设置步长为2，这样只会有3，5，7这三个值
    connect(cannyKernelSizeSpinBox, QOverload<int>::of(&QSpinBox::valueChanged), this, &MainWindow::setCannyKernelSize);
    cannyKernelSize = 3; // 设置默认值

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(resizeLabel);
    layout->addWidget(sizeSpinBox);
    layout->addWidget(lightenDarkenLabel);
    layout->addWidget(brightnessSpinBox);
    layout->addWidget(dilateLabel);
    layout->addWidget(dilateSpinBox);
    layout->addWidget(erodeLabel);
    layout->addWidget(erodeSpinBox);
    layout->addWidget(imageLabel);
    layout->addWidget(view);
    layout->addWidget(cannyKernelSizeLabel);
    layout->addWidget(cannyKernelSizeSpinBox);

    QWidget *widget = new QWidget(this);
    widget->setLayout(layout);
    setCentralWidget(widget);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::openPicture()
{
    QString fileName = QFileDialog::getOpenFileName(this);
    if (!fileName.isEmpty()) {
        image.load(fileName);
        pixmapItem->setPixmap(QPixmap::fromImage(image));
        scene->setSceneRect(image.rect());
    }
}

void MainWindow::openImages()
{
    QStringList fileNames = QFileDialog::getOpenFileNames(this);
    if (!fileNames.isEmpty()) {
        images.clear();  // 清空图片列表
        qreal gap = 0; // 设置图片间距
        foreach (const QString &fileName, fileNames) {
            QImage img;
            if (img.load(fileName)) {  // 加载成功，添加到图片列表
                images.append(img);

                // 创建新的 QPixmap 并添加到场景中
                QGraphicsPixmapItem *newPixmapItem = new QGraphicsPixmapItem(QPixmap::fromImage(img));
                if (!pixmapItems.isEmpty()) {
                    // 获取上一个 QPixmap 的右侧边界位置，添加间隔
                    qreal lastRightEdge = pixmapItems.last()->boundingRect().right() + pixmapItems.last()->pos().x() + gap;
                    // 将新的 QPixmap 位置设为上一个 QPixmap 的右侧加上间隔
                    newPixmapItem->setPos(lastRightEdge, 0);
                }
                scene->addItem(newPixmapItem);
                pixmapItems.append(newPixmapItem);
            }
        }
        if (!pixmapItems.isEmpty()) {
            // 设置场景的矩形为最后一个 QPixmap 的矩形，需要考虑间隔
            scene->setSceneRect(0, 0, pixmapItems.last()->boundingRect().right() + pixmapItems.last()->pos().x() + gap, pixmapItems.last()->boundingRect().bottom());
        }
    }
}


void MainWindow::panorama()
{
    // 首先检查是否有足够的图片进行拼接
    if (images.size() < 2) {
        // 在这里可以添加错误处理代码，比如弹出一个对话框告诉用户至少需要两张图片
        return;
    }

    // 然后将QImage列表转换为cv::Mat列表，因为OpenCV的Stitcher类需要cv::Mat列表作为输入
    std::vector<cv::Mat> mats;
    foreach (const QImage &qimage, images) {
        // 进行深度复制，确保在更改cv::Mat时不会影响到原始的QImage
        QImage imgCopy = qimage.copy();
        mats.push_back(cv::Mat(imgCopy.height(), imgCopy.width(), CV_8UC3, imgCopy.bits(), imgCopy.bytesPerLine()).clone());
    }

    // 使用默认设置创建一个Stitcher实例
    cv::Ptr<cv::Stitcher> stitcher = cv::Stitcher::create();
    cv::Mat pano;
    cv::Stitcher::Status status = stitcher->stitch(mats, pano);

    // 检查拼接操作是否成功
    if (status != cv::Stitcher::OK) {
        // 在这里添加错误处理代码，比如弹出一个对话框告诉用户全景图生成失败
        return;
    }

    // 最后将拼接得到的全景图转换为QImage并显示
    panoramaImage = QImage((const unsigned char*)pano.data, pano.cols, pano.rows, pano.step, QImage::Format_RGB888).rgbSwapped();
    pixmapItem->setPixmap(QPixmap::fromImage(panoramaImage));
    scene->setSceneRect(panoramaImage.rect());
    // 将BGR转换为RGB并转换为QImage


}
void MainWindow::savePicture()
{
    // Get file path from user
    QString filePath = QFileDialog::getSaveFileName(this, tr("Save Picture"), "", tr("Images (*.png *.xpm *.jpg)"));

    // If user didn't cancel the dialog
    if (!filePath.isEmpty())
    {
        // Convert the QPixmap to QImage and then save the QImage
        pixmapItem->pixmap().toImage().save(filePath);
    }
}





// MainWindow.cpp


void MainWindow::setCannyKernelSize(int size)
{
    if (size == 3 || size == 5 || size == 7) {
        cannyKernelSize = size;
    } else {
        // 弹出警告框，提示用户输入的值无效
        QMessageBox::warning(this, tr("Invalid Input"), tr("Aperture size should be odd between 3 and 7."));
    }
}


void MainWindow::cannyEdgeDetection()
{
    qDebug() << "Image size:" << image.size();
    qDebug() << "Image format:" << image.format();
    if (!image.isNull()) {
        // Convert QImage to cv::Mat
        cv::Mat img = cv::Mat(image.height(), image.width(), CV_8UC4, (void*)image.bits(), image.bytesPerLine());
        std::cout<<img;
        // Ensure the image data is loaded
        if (!img.empty()) {
            // Convert ARGB to grayscale
            cv::cvtColor(img, img, cv::COLOR_BGRA2GRAY);

            cv::Mat edges;
            // Use cannyKernelSize parameter for Canny function
            cv::Canny(img, edges, 50, 200, cannyKernelSize); // Here, 50 and 200 are thresholds

            // Convert cv::Mat edges back to QImage for display
            QImage cannyImage = QImage(edges.data, edges.cols, edges.rows, edges.step, QImage::Format_Grayscale8);
            pixmapItem->setPixmap(QPixmap::fromImage(cannyImage));
            scene->setSceneRect(cannyImage.rect());
        }
    }
}


// 实现Canny边缘检测功能

void MainWindow::updateImageSize(int size)
{
    if (!image.isNull()) {
        QImage scaledImage = image.scaled(size, size, Qt::KeepAspectRatio);
        pixmapItem->setPixmap(QPixmap::fromImage(scaledImage));
        scene->setSceneRect(scaledImage.rect());
    }
}


void MainWindow::updateBrightness(int level)
{
    if (!image.isNull()) {
        // Convert QImage to cv::Mat
        cv::Mat cvImage = cv::Mat(image.height(), image.width(), CV_8UC4, (void*)image.bits(), image.bytesPerLine());

        // Modify brightness
        cvImage.convertTo(cvImage, -1, 1, level);

        // Convert back to QImage
        QImage newImage = QImage((const unsigned char*)cvImage.data, cvImage.cols, cvImage.rows, cvImage.step, QImage::Format_RGB32);
        pixmapItem->setPixmap(QPixmap::fromImage(newImage));
        scene->setSceneRect(newImage.rect());
        // 根据SpinBox的值改变图片亮度
    }
}

void MainWindow::updateDilation(int dilationSize)
{
    if (!image.isNull()) {
        // Convert QImage to cv::Mat
        cv::Mat cvImage = cv::Mat(image.height(), image.width(), CV_8UC4, (void*)image.bits(), image.bytesPerLine());

        // Apply dilation
        cv::dilate(cvImage, cvImage, cv::getStructuringElement(cv::MORPH_RECT, cv::Size(dilationSize, dilationSize)));

        // Convert back to QImage
        QImage newImage = QImage((const unsigned char*)cvImage.data, cvImage.cols, cvImage.rows, cvImage.step, QImage::Format_RGB32);
        pixmapItem->setPixmap(QPixmap::fromImage(newImage));
        scene->setSceneRect(newImage.rect());
    }
}

void MainWindow::updateErosion(int erosionSize)
{
    if (!image.isNull()) {
        // Convert QImage to cv::Mat
        cv::Mat cvImage = cv::Mat(image.height(), image.width(), CV_8UC4, (void*)image.bits(), image.bytesPerLine());

        // Apply erosion
        cv::erode(cvImage, cvImage, cv::getStructuringElement(cv::MORPH_RECT, cv::Size(erosionSize, erosionSize)));

        // Convert back to QImage
        QImage newImage = QImage((const unsigned char*)cvImage.data, cvImage.cols, cvImage.rows, cvImage.step, QImage::Format_RGB32);
        pixmapItem->setPixmap(QPixmap::fromImage(newImage));
        scene->setSceneRect(newImage.rect());
    }
}
